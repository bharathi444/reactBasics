// //date object
// const date = Date().toString();
// console.log(date);
// const now = new Date(); //object
// console.log(now.getDay())

// //custom date
// const anotherDate=new Date("July 6 1996")
// console.log(anotherDate.getDay(),anotherDate.getFullYear());

//refer:   https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date#to_get_date_month_and_year_or_time
 


const todayDate = Date().toString//Date()
console.log(todayDate);
const todayDay = new Date().getTime();
console.log(todayDay);

