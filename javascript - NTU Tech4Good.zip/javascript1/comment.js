// comment // -------- single line

/*
console.log("hello") -----------multiple line
*/
