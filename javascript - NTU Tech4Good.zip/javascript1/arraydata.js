let favColr = []
console.log(favColr);

let color = ["red","blue"]
console.log(color[0])

// adding values
color[4]="yellow"
console.log(color)
console.log(color.length)