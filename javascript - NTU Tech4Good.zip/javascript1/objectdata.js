let name = "xyz";
let age = 21;
let gender = "female";
let address = "chennai,india";

// object
let person = {
  name: "xyz",
  age: 22,
  sibling: {
    bro: "yyy",
    sis: "qqqq",
  },
};
console.log(person);
// . notation
console.log(person.name);
console.log(person.sibling);
console.log(person.sibling.bro);

person.age = 45;

//bracket
console.log(person["age"]);

//calling variables inside function
function greeting() {
  let msg = "my name is " + name + " my age is" + age;

  console.log(msg);
}
greeting();

// Template literals `` "$"---------- calling dynamic variables
function greeting1() {
  let msg1 = `my name is ${name}`;
  console.log(msg1);
}
greeting1();

//writing function inside object:
let person1 = {
  user_name: "bharathi",
  age: 23,
  interest: ["websitesdev", "mobileappdev"],
  address: {
    city: "chennai",
    state: "TamilNadu",
  },
  greeting: function () {
    //accessig variable inside the objects (this keyword)  this means person1 object
    // let msg = `my name is ${user_name} `; --- error
    let msg = `my name is ${this.user_name}`;
    console.log(msg);
  },
};
console.log(person1.greeting);

person1.greeting();

//factory functions
// creating common functions in single function --------creating person

function createPerson1(name1){
    let personData={
        name:name1,
        greeting2:function(){
            let msg = `my name is ${this.name}`;
            console.log(msg);

        }
    };

    return personData;

}
let X = createPerson1("data1")
X.greeting2();

//simplified version of factory function
// function createPerson(name) { //camel case
//   return {
//     name: name, //or name,
//     greeting2: function () {
//       let msg = `my name is ${this.name}`;
//       console.log(msg);
//     },
//   };
// }
// let personX = createPerson("bharathi");
// let personY = createPerson("bharathiY");
// personX.greeting2();
// personY.greeting2();

//constructor func ---- oop language
function Person(name) //pascal -> firstletter caps
{
    this.name=name,
    this.greeting=function(){
        let msg = `my name is ${this.name}`;
       console.log(msg);

    }
}
let PersonZ=new Person("zzz"); //new------1.creating empty obj let x={} ,2.this is referencing n mapping ,3.return this
PersonZ.greeting();


//dynamic object
const PersonA={
    name:"personA"
}
console.log(PersonA);
PersonA.age=24;
PersonA.greeting=function(){} // adding members to object
delete PersonA.greeting;



//inbuilt literal types
let m ={}; //new object(){}
let personm="personm"; // new String("personm")
let age =56; // new Number(4)
