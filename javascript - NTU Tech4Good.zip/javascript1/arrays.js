//arrays : collections of multiple items,it can be any dataType

const cart = ["fruits", 1, true];
const numcart = [2, 3, 4, 5, 6];
console.log(numcart);
console.log(numcart[1]);
console.log(cart[0]);

// push operation
cart[3] = "orange";
console.log(cart);
cart.push("lemon", "grapes");
console.log(cart);

//unshift adding item front
cart.unshift("apple");
console.log(cart);

//splice push in specific location
cart.splice(2, 0, "watermelons", "bananas");
console.log(cart);

//finding element
console.log(cart.indexOf("fruits"));
console.log(cart.indexOf("gouva"));
if (cart.indexOf("grapes") !== -1) {
  console.log("true");
}
// combining arrays
const shoppingCart = ["maggi", "fries", "burger"];
const drinks = ["pepsi", "shakes"];
const masala = [{ chilli: "chilliflakes" }];
let foodie = shoppingCart.concat(drinks);
console.log(foodie);
console.log(foodie.concat(masala));
// xtract
console.log(foodie.slice(1, 3));

//spread operator ... modern approach es6 for combining arrays
let foodie1 = [...shoppingCart, ...masala];
console.log([45, ...foodie1, ...drinks]);

const orders = [
  { id: 1, item: "noodles", qty: 3 },
  { id: 3, item: "fries", qty: 1 },
  { id: 2, item: "burger", qty: 1 },
];

//joining and splitting
const dailyRoutine = ["wakeup", "eat", "sleep"];
console.log(dailyRoutine.join(", "));

let fullName = "bharathi sambath";
let name = fullName.split(" ");

console.log(fullName.split(" "));
console.log(name[0], name[1]);

//sorting an array
const students = [1, 4, 6, 2];
console.log(students);
console.log(students.sort());
students.sort(function (a, b) {
  return b - a;
});
console.log(students);
//reversing an array
students1 = [3, 4, 5, 6];
console.log(students1.reverse());

const data = [
  { id: 1, name: "xxx" },
  { id: 2, name: "zyyy" },
  { id: 3, name: "yzzz" },
];
console.log(data);
 let sortedData= data.sort(function (a, b) {
  //ascii table
  //a<b => -1 position one step back
  //a>b =>+1
  // a==b => 0
  if (a.name < b.name) return -1;
  else if (a.name > b.name) return 1;
  return 0;
});
console.log(sortedData);




//filtering 
const queue_by_age = [23,45,56];
let Adults= queue_by_age.filter(function(value){
  return value > 38;

});
console.log(Adults);

const nums=[1,2,3,4,5,6,7,8];
let evenNum = nums.filter(function(value){
  return(
    value%2 == 0
  )
})
console.log(evenNum);

const cart_items = [
  {id:1,item:"android mobile",cost:12000},
  {id:2,item:"iphone" , cost:100000},
  {id:3,item:"laptop" , cost:45000}
];
let lessAffordable=cart_items.filter(function(itemcost){
  return itemcost.cost < 100000;

});
console.log(lessAffordable);

//checking item
//find - return obj
//findindex() - return index
//refer : https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array

let result1 = orders.find(function (order) {
  return order.item === "noodles";
});
console.log(result1);
let result = orders.findIndex(function (order) {
  return order.item === "noodles";
});
console.log(result);
