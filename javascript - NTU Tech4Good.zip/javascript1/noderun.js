console.log("hello world")
//node <file name>
//for eg: node noderun.js