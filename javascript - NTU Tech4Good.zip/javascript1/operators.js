
// let number1=10
// let number2=30
// let char ="data"
// let char1="data1"
// console.log(char+char1)
// let i =8;
// console.log(number1+number2)
// console.log(++i);




let num1=20;
let num2 =12;

// // console.log(num1++); //num=num+1
// console.log(++num1); num=num+1
// console.log(++num1);
// console.log(num1++);num=num+1
// console.log(num1)

// let number=20;
// console.log(number++);



// // increment ++
// console.log(++number1)
// console.log(number1++)
// console.log(number1)

// //decrenmrnt


// assignment operators
let v=10;
// v=v+12;   // (v = v+12) ( v+=12)
// console.log(v);
// let v1 =20;
// v1+=12;
// console.log(v1) //22

// console.log(v)

// // comparison ope

// console.log(11<5);
// console.log(11>=11);
// console.log(10 ==10);
// console.log("i" > "j"); //values are compared by ascii table
// // console.log("i" > "j"); 

//&& || !
console.log(false && true);
let j=30;
console.log( j ==30 && j<50 && j<90);
 let k=20;
 console.log( k>20 || k<30);
 console.log(!false);

// //logical
// console.log(false && true)

// console.log(false || true)
// console.log(!true)

