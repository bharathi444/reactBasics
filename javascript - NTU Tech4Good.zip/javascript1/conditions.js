//Conditional statements are used to perform different actions based on different conditions.
// if loop



const x = 9;
if (x == 9) {
  console.log("number is 9");
} else {
  console.log("no not found");
}
//----------------------------------------------------
//date object
const date = Date().toString();
console.log(date);
const now = new Date(); //object
console.log(now.getDay())

//custom date
const anotherDate=new Date("July 6 1996")
console.log(anotherDate.getDay(),anotherDate.getFullYear());

//refer:   https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date#to_get_date_month_and_year_or_time
let hour = new Date().getHours();
console.log(hour);

if (hour >= 0 && hour <= 13) {
  console.log("Good morning");
} else if (hour >= 13 && hour <= 17) {
  console.log("good afternoon");
} else {
  console.log("good evening");
}

//ternary operator 

// person age 18--adult
// <18 ---minor
let age =23;
// if(condtion){
//     //condtion
// }
// else{
//     // condtion
// }
let type =age >18 ? "adult Ticket" : "child";
console.log(type)
age>18 ? console.log("adult") : console.log("child");

// switch
let grade = "A";
switch (grade) {
  case "S":
    console.log("super grade");
    break;
  case "A":
    console.log("excellent grade");
    break;
  case "B":
    console.log("just pass");
    break;
  case "U":
    console.log("Fail");
    break;
    default:
        console.log("unknown grade");
}

// for
// for(initial exp,condition ,step ++){

// }
for (let i=0;i<5;i++){
    if(i%2 !== 0)
    console.log("odd number is " , i);
}
//while loop
// let int1=20;
// while(int1>0){
//     if(int1%2 !==0){
//         console.log("odd number" ,int1);
//     }
// }
let i=20;
while(i>=1){
  if(i%2!==0){
    console.log("odd num" , i)
  }
  i--;
}
//for-in loop ----- loops statements through properties of an object and arrays
const person = {
  name:"bharathi",
  age:23,
  gender:"female"
};
for (let key in person){
  console.log(key);
  console.log(person[key]);
  
};

let colors= ["red" ,"blue" ,"green"];
for (let i in colors){
  console.log(i , colors[i])
}

//for -of  - no need to give index
for (let color of colors){
  console.log("color:" + color)
};

