// const numbers =[1,2,3,4,5,6,7];
// let mapFun = numbers.map(function(value){
//   return value+2;
// });
// console.log(mapFun);


// normal fun
addition(10);
function addition(num) {
  return console.log(num + 20);
}  ///30


//find returning finding array
const orders = [
  { id: 1, item: "noodles", qty: 3 },
  { id: 3, item: "fries", qty: 1 },
  { id: 2, item: "burger", qty: 1 },
];
let result = orders.find(function (order) {
  return order.item === "burger";
});
console.log(result);
//arrow   // () => {}
const hello = () => {
  return console.log("hello world");
};
hello();

const addition1 = (num) => {
  return console.log(num);
};
addition1(1);

let result_arrowFun = orders.find((order) => {
  return order.item === "burger";
});
console.log(result_arrowFun);

//map fun //map function -changing behaviour of own elements
const numbers = [65, 44, 12, 4];

const newArr = numbers.map(myFunction);

function myFunction(num) {
  return num * 10;
}
console.log(newArr);

// function myFunction(num){
//     return(
//         console.log(num)
//     )
// }

const numbers = [1, 2, 3, 4, 5, 6, 7];
let mapFun = numbers.map(function (value) {
  return value + 2;
});
console.log(mapFun);
