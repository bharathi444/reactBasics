// function Greetings(){
//     console.log("hii ")
// };
// Greetings();

// function Greetings(name1,lastName){
//     console.log("hii " + name1 + lastName)
// };
// Greetings("bharathi" , "sambath");
// Greetings("bharathi1");
// // calling paamete  name 1  parameter ---bharathi -arg 

// function add(n1,n2){
//     result=n1+n2;
//     console.log(result)
// }
// add(2,3)

// fun = ();

//  let num1=20;
// let num2=40;
// console.log(num1+num2);

// function welcome(){
//     console.log("hello");
//     return(
//         console.log("hi welcome")
        
//     )
    

// }

// welcome();

// function mul(x,y){
//     return(
//         console.log(x * y)
//     )
// }


// mul(30 ,20);




