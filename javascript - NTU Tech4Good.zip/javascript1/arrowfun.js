//arrow function vs normal function

//normal func
const orders = [
  { id: 1, item: "noodles", qty: 3 },
  { id: 3, item: "fries", qty: 1 },
  { id: 2, item: "burger", qty: 1 },
];
let result = orders.find(function (order) {
  return order.item === "burger";
});
console.log(result);
// () => {}
///--------------------------------------------------------------
let result_arrowFun = orders.find((order) => {
  return order.item === "burger";
});
console.log(result_arrowFun);
//-----------------------------------------------------------------

let result_arrowFun1 = orders.find((order) => order.item === "burger");
console.log(result_arrowFun1);

//iterating elements
const dailyRoutine = ["wake up", "eat", "sleep"];
//for-of -----looping statement
for (let routine of dailyRoutine) {
  console.log(routine);
}
//for -in
for (let routine in dailyRoutine) {
  console.log(routine);
  console.log(dailyRoutine[routine]);
}
//for-each
dailyRoutine.forEach(function (routine,index) {
  console.log( index,routine);
});

//arrowfun
dailyRoutine.forEach((routine) => {console.log(routine)})


//map function -changing behaviour of own elements
const numbers =[1,2,3,4,5,6,7];
let mapFun= numbers.map(function(value){
  return value+2;
});
console.log(mapFun);

const people= [
  {id:1,firstName:"ajith" ,lastName:"kumar"},
  {id:1,firstName:"ajith2" ,lastName:"kumar2"},
  {id:1,firstName:"ajith3" ,lastName:"kumar3"},
  {id:1,firstName:"ajith4" ,lastName:"kumar4"}
];
let fullName= people.map((value) => {
  return(
    // value.firstName+value.lastName
    [value.firstName,value.lastName].join(" ")
  )
})
console.log(fullName);

let fullName1= people.map((value) => {
  
    // value.firstName+value.lastName
    let fullName = [value.firstName,value.lastName].join(" ");
    let obj ={id:value.id,fullName:fullName}
    return obj;
  
})
console.log(fullName1);

//chaining method
//sort it using lowest price -> sort it by title ascending -> filter products less than 8000 -> map it like this ://android phone - rs.3900

