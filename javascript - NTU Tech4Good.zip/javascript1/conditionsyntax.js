// //if
// if (condition) {
//   //  block of code to be executed if the condition is true
// }

// //if-else
// if (condition) {
//   //  block of code to be executed if the condition is true
// } else {
//   //  block of code to be executed if the condition is false
// }

// //The switch statement is used to perform different actions based on different conditions. -- switch
// switch(expression) {
//     case x:
//       // code block
//       break;
//     case y:
//       // code block
//       break;
//     default:
//       // code block
//   }
// refer :w3schools

//if condtion //if else //if else if

// var num=1;

// if(num ==14){
//   console.log("yes!num is 12");
// }
// else if (num==13){
//   console.log("yes num is 13")
// }
// else if(num==15){
//   console.log("yes num is 15")
// }
// else{
//   console.log("not found!");

// }
//
//  switch loop

// let grade = "U";

// switch (grade) {
//   case "S":
//     console.log("super grade");
//     break;
//   case "A":
//     console.log("excellent grade");
//     break;
//   case "B":
//     console.log("just pass");
//     break;
//   case "U":
//     console.log("Fail");
//     break;
//     default:
//         console.log("unknown grade");
// }

// for
// for(initial exp,condition ,step ++){}

// let value = 20;
// //numbers from 1 to 10
// for (i = 0; i <= 10; ++i) {
//   console.log(i);
// }

// for (let i=0;i<=5;i++){
//   if(i%2 == 0)
//   console.log("even number is " , i);
// }


// var i = "abc";
  //for in 
   
const person = {
  name:"bharathi",
  age:23,
  gender:"female"
};

// for (let key in person){
//   console.log(key);
//   console.log(person[key]);
  
// };

// for (let key in person){
//   console.log( key ,person[key]);
  
// }

// for of loop

//for -of  - no need to give index
// for (let key of person){
//   console.log("key:" + key)
// };


// let colors= ["red" ,"blue" ,"green"];
// for (let i in colors){
//   console.log(i , colors[i])
// }

// //for -of  - no need to give index
// for (let color of colors){
//   console.log( color)
// };

// let number =20;
// console.log(number--);



