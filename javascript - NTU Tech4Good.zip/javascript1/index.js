
alert("hello");
alert(4+5);
console.log("message");


var name ="bharathi"
var msg="hi" + name ;
var data =10

var x=10
var X=20
console.log(x,X)
console.log(msg + data)
alert(msg)

let number1 = 10;
let number2 =20;
console.log(number1+number2)

let x1=10;
x1=17;
console.log(x1)


const dob="09-79-1999"
const employ="nivi"
let msg1="hello "+ employ +"born on " +dob;

console.log(msg1)
// rules:
// 1. no js keywords ---- dont use keywords(if,for,while)
// 2.should not start with number (let 6="nj" )
// 3.no space,no - ( var bha 5 =10,var bha-2 =8)
// 4.camelcase for understanding
// 5.use meaningfull related names