// //regualr functions
// function Dummy (){
//   return(
//     console.log("hello!!") //hello! + username
//   )

// }
// Dummy();
// function greeting(){
//     return(
//         console.log("hello" + "bharathi")
//     )
// }
// greeting();

// function greeting1(username){
//     return(
//         console.log("hello" + username)
//     )
// }
// greeting1(10); //10 // "10"
// greeting1("person1");

// function addition(num1,num2){
//     return(
//         console.log(num1+num2)
//     )
// }
// addition(20,10);

//arrow functions  //es6 let ,arrow     ----    () => {/code block}

// function Dummy() {
//   return console.log("hello!!"); //hello! + username
// }
// Dummy();

//arrow   // () => {}

// const functionname = () => {
//     return (
//         //code block
//     )
//   };

// const Dummy1 = () => {
//   return console.log("hello!!");
// };

// Dummy1();

// const Dummy1 = (namee) => {console.log("hi!!" + namee)}
// Dummy1("bharathi");

// const orders = [
//     { id: 1, item: "noodles", qty: 3 },
//     { id: 3, item: "fries", qty: 1 },
//     { id: 2, item: "burger", qty: 1 },
//   ];
//   let result = orders.find(function (order) {
//     return order.item === "burger";
//   });
//   console.log(result);

//[] --  {}
//  const orders = [
//         { id: 1, item: "noodles", qty: 3 },
//         { id: 3, item: "fries", qty: 1 },
//         { id: 2, item: "burger", qty: 1 },
//      ];
// console.log(orders);

// let output = orders.find(function(order))

//map fun //map function -changing behaviour of own elements
// const numbers = [65, 44, 12, 4];

// const newArr = numbers.map(myFunction);

// function myFunction(num) {
//   return num * 10;
// }
// console.log(newArr);

// // function myFunction(num){
// //     return(
// //         console.log(num)
// //     )
// // }

// const numbers = [1, 2, 3, 4, 5, 6, 7];
// let mapFun = numbers.map(function (value) {
//   return value + 2;
// });
// console.log(mapFun);

// const numbers= [1,2,3,4,5,6,7,8,9,10];
// console.log(numbers);
// //10,20,30,........100

// let output = numbers.map(function (number){
//     return(
//         console.log(number*10)
//     )

// } )

// const orders = [
//     { id: 1, item: "noodles", qty: 3 },
//     { id: 3, item: "fries", qty: 1 },
//     { id: 2, item: "burger", qty: 1 },
//   ];
// // { id: 2, item: "burger", qty: 1 },

const orders = [
  { id: 1, item: "noodles", qty: 3 },
  { id: 3, item: "fries", qty: 1 },
  { id: 2, item: "burger", qty: 1 },
];
// {if noodles just display that object} // {id:3} burger id is 2
let items = orders.map(function (keyvalue) {
        if (keyvalue.item == "noodles") {
    console.log("burger id is ", keyvalue.id)
  }

    
 
});
