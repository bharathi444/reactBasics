import "./calculator.css";
import React, { useState } from "react";

const Calculator = () => {
  const [calc, setCalc] = useState("");
  const [results, setResults] = useState("");
  //   const[calculateAns,setCalculateAns] = (" ");

  const ops = ["/", "*", "+", "-", "."];
  const updateCalc = (value) => {
    if (
      (ops.includes(value) && calc === "") ||
      (ops.includes(value) && ops.includes(calc.slice(-1)))
    ) {
      return;
    }

    setCalc(calc + value);
    if (!ops.includes(value)) {
      setResults(eval(calc + value).toString());
    }
    console.log(ops.includes(value));
    console.log(value);
  };
  const createDigits = () => {
    const digits = [];
    for (let i = 1; i < 10; i++) {
      digits.push(
        <button
          onClick={() => {
            updateCalc(i);
          }}
          key={i}
        >
          {i}
        </button>
      );
    }
    return digits;
  };

  console.log(createDigits());
  const calculate = () => {
    setCalc(results);
  };
  const deleteLast = () => {
    if (calc == "") {
      console.log("null");
      return null;
    }
    console.log("clikd");
    const value = calc.slice(0, -1);
    setCalc(value);
    // setCalc("")
    // setResults("")
  };

  return (
    <div className="calculator">
      <div className="display">
        {results ? <span>({results})</span> : ""} {calc || 0}
      </div>
      <div className="operators">
        <button
          onClick={(e) => {
            updateCalc("/", e);
          }}
        >
          /
        </button>
        <button
          onClick={() => {
            updateCalc("*");
          }}
        >
          *
        </button>
        <button
          onClick={() => {
            updateCalc("+");
          }}
        >
          +
        </button>
        <button
          onClick={() => {
            updateCalc("-");
          }}
        >
          -
        </button>
        <button onClick={deleteLast}>DEL</button>
      </div>
      <div className="digits">
        {createDigits()}
        <button
          onClick={() => {
            updateCalc("0");
          }}
        >
          0
        </button>
        <button
          onClick={() => {
            updateCalc(".");
          }}
        >
          .
        </button>
        <button onClick={calculate}>=</button>
      </div>
    </div>
  );
};

export default Calculator;
