import React from "react";
import { useState, useEffect } from "react";

export default function Apiget() {
  const [data, setData] = useState([]);
  const[loading,setLoading] = useState(true);
  const[error,setError] = useState(null)

  useEffect(() => {
   
    fetch("https://jsonplaceholder.typicode.com/posts")
      .then((response) => {
        console.log(response);
        if(!response.ok){
            throw Error("errorrrrrrr")
        }
        return response.json();
      })
      .then((json) => {
          setData(json)
          setLoading(false)
          setError(null)
    }).catch(
        (err) => {
            // console.log(error.message)
            setError(err.message)
            setLoading(false)
        }

    )
    
  },[]);

console.log(data)
  return (
    <div>
      <h1>api get request s</h1>
      <h1>The data is</h1>
      {loading && (<div> <img src="https://miro.medium.com/max/700/1*CsJ05WEGfunYMLGfsT2sXA.gif" /></div>)}
      {error && (<div>{error}</div>)}
      { data && data.map((value,key) => {
          return(
            <div key={key}>{value.title}</div>

          )
        
      })}
    </div>
  );
}
