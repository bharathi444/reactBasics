import React from 'react'

export default function FunctionComponents() {
    return (
        <div>
            <h1>hi ,I am functional Components</h1>
        </div>
    )
}
