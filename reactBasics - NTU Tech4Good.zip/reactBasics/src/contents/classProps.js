import React, { Component } from "react";

export default class ClassProps extends Component {
  render() {
    return (
      <div>
        <h1>Class props is given by this keyword</h1>
        <p>this is pointed to their object</p>
        {this.props.name}
      </div>
    );
  }
}

//instead of giving this .props.name inside return ,you can change that to give some naming for thhis.props.name
//just comment last code and umcomment the below to view result

// import React, { Component } from "react";

// export default class ClassProps extends Component {
//   render() {
//     const Name = this.props.name;
//     return (
//       <div>
//         <h1>Class props is given by this keyword</h1>
//         <p>this is pointed to their object</p>
//         {Name}
//       </div>
//     );
//   }
// }
