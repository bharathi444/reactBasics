import React ,{useState}from 'react'

export default function OnSumbitForm() {
    const[name,setName] = useState("");
    const[age,setAge] = useState("")
    const[password,setPassword]=useState("");
    const submitForm = (e) =>{
        e.preventDefault();
        console.log({name},{age},{password})
    }
    return (
        <div style={{display:"flex"}}>
            <form onSubmit={submitForm}>
                <label>UserName</label>
                <br />
                <input type="text" value={name} onChange = {(e) => setName(e.target.value)}></input>
                <br/>
                <label>Age</label>
                <br />
                <input type="number" value={age} onChange = {(e) => setAge(e.target.value)}></input>
                <br />
                <label>password</label>
                <br />
                <input type="password" value={password} onChange = {(e) => setPassword(e.target.value)}></input>
                <br /><br />
                <button style={{color:"yellow" , backgroundColor:"blue"}}>SUBMIT FORM</button>
            </form>
            {name}{password}{age}
        </div>
    )
}
