import React, { useState } from "react";

const Post = () => {
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const[userId,setUserId]=useState("");
  const[loading,setLoading] = useState(false);
 
  

  const hanleSumbit = (e) => {
    e.preventDefault();

    const blog = { title, body,userId };
    setLoading(true);
    console.log(blog);
    fetch("https://jsonplaceholder.typicode.com/posts" , {
        method:"POST",
        headers:{"content-Type":"application/json"},
        body:JSON.stringify(blog)
    }).then((response) => response.json()).then((json) =>{
      console.log("new post added")
      console.log(json);
      setLoading(false)
  })
 
  };
  return (
    <>
     
      <div>
        <form onSubmit={hanleSumbit}>
          <label>Post Title</label>
          <input
            type="text"
            required
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />
          <label>UserId</label>
          <input
            type="text"
            required
            value={userId}
            onChange={(e) => setUserId(e.target.value)}
          />
          <label>Post body</label>
          <textarea
            required
            value={body}
            onChange={(e) => setBody(e.target.value)}
          ></textarea>
          {!loading && <button style={{color:"black"}} >Add Post</button>}
          {loading && (<button style={{color:"black"}}  disabled>Adding data...</button> )}
        </form>
       
      </div>
    </>
  );
};

export default Post;
