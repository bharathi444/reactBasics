const ArrowFunction = () => {
    return ( 
        <h1>hi,I am ArrowFunction Component</h1>
     );
}
 
export default ArrowFunction;