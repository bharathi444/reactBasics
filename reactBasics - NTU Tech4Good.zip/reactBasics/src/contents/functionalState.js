import React, { useState } from "react";

export default function FunctionalState() {
  const [message, setMessage] = useState("Hi Welcome");
  const [count, setCount] = useState(0);

  const changeMessage = () => {
    setCount(count + 1);
    setMessage("thank you!");
  };
  

  return (
    <div>
      <h1>hi hooks</h1>
      {message}
      {count}
      <button
        onClick={changeMessage}
        style={{ borderRadius: "2px", backgroundColor: "black" }}
      >
        click here
      </button>
    </div>
  );
}
