import React , {useEffect,useState} from 'react'
 // Each component has several “lifecycle methods” that you can override to run code at particular times in the process
export default function Useeffect() {
    const[count,setCount] = useState(0);
    const[message,setMessage] = useState("hi")
    const incre = () =>{
        setCount(count+1);
    }
    
    // useEffect(() => {
    //     effect
    //     return () => {
    //         cleanup
    //     }
    // }, [input])
    console.log("rerender")
    useEffect(() => {
        console.log("useeffect")

    },[message])
    return (
        <div>
            <button onClick={incre}>increment</button>
            <h1>{count}</h1><h4>{message}</h4>
            <button onClick = {() => setMessage("thankyou")}>messagechange</button>
            useffect
        </div>
    )
}
