import React , {useState} from 'react'

export default function OnclickFunction() {
   
    const [isOpen, setIsOpen] = useState(false);
    const[count,setCount] = useState(0)

    const buttonCss = {
        color:"yellow",
        backgroundColor:"blue",
    }
    const ChangeClick = function(Visitor){
        console.log("hi" , Visitor)
        console.log("hi,clicked")
    }
    const handleClickMe = ( name,e ) => {
        console.log("hello" ,name,e, e.target );
    }
  const ChangeClick1 = (name ,e) => {
   console.log(name,e,e.target)
  }
  const openPopup = function(){
      setIsOpen(true)
      console.log("popup")
  }
  const handleClose = function(){
   
       setIsOpen(false)
       setCount(count+1)

 
  }
 
    return (
        <div>
           

             <button style= {buttonCss} onClick = {(e) => {ChangeClick("bharathi" , e)}}>simple onclick</button>
           
            <button onClick= { (e) => {handleClickMe("bharathi" , e)}}>Click Me!</button>
            <br/>
            <br />
            <button style= {buttonCss} onClick = {openPopup}>click to open popup</button> 
            <br/><br/>
            {isOpen && <div style={{display:'flex'}}> <h1 style={{color:"green" ,padding:"20px" ,backgroundColor:"greenyellow" }} >Hi ,Im popup {count}<span onClick={handleClose} style={{color:"black" ,cursor:'pointer'}}>X</span></h1></div>} 
            
        </div>
    )
}
