import React, { Component } from 'react'
// Note: Always start component names with a capital letter.

export default class ClassComponent extends Component {
    render() {
        return (
            <div>
                <h1>hi,im Class component</h1>
            </div>
        )
    }
}

