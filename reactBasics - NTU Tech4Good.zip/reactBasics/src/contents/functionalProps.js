import React from 'react'

export default function FunctionalProps(props) {
    return (
        <div>
            {props.name}
            
        </div>
    )
}

//destructing the props //instead og giving props.name ,you can give {name} in function declaration line
//{name} = props.name -- destructing
//comment above code and umcomment below code to view results

// import React from 'react'

// export default function FunctionalProps({name}) {
//     return (
//         <div>
//             {name}
            
//         </div>
//     )
// }

