import React, { useEffect } from "react";
import { useState } from "react";

export default function GetApi() {
  const [post, setPost] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  useEffect(() => {
    fetch("https://jsonplaceholder.typicode.com/posts")
      .then((response) => response.json())
      .then((data) => {
        setPost(data);
        setLoading(false);
      })
      .catch((err) => {setError("error!") 
                  setLoading(false)})
  }, []);
  console.log(post);
  return (
    <div>
      {loading && <div>loading........</div>}
      {error && <div>{error}</div>}
      hi
      {post.map((value, key) => {
        return (
            <div>
            <h1 key={key}>{value.id}</h1>
            <p>{value.title}</p>
            </div>
        );
      })}
    </div>
  );
}
