import React, {useState} from "react";

export default function Onchange() {
  const[user,setUser] = useState("")
    const [name, setName] = useState("");
    const updateName = (namee) =>{
        setName(namee.target.value)
        console.log("upadte" ,namee.target.value ,namee)
    }
  
  return (
    <div>
      <form>
       <label>
        Enter your name:
        <input
          type="text"
          value={name}
        //   onChange={(e) => setName(e.target.value)}
        onChange = {(e) => {updateName(e)}} 
        />
      </label>
      
      </form>
      {name} 
     
     
    </div>
  );
}
