const ArrowFunctionProps = ({ name }) => {
  return <div>{name}</div>;
};

export default ArrowFunctionProps;
