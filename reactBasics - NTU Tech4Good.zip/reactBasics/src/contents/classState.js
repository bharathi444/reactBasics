import React, { Component } from "react";

export default class ClassState extends Component {
  constructor() {
    super();

    this.state = {
      message: "hi welcome",
      count: 1,
    };
  }

  changeMessage = () => {
    this.setState({ message: "thankyou!", count: this.state.count + 1 });
  };

  render() {
    return (
      <div>
        <h1>{this.state.message}</h1>
        <h1>{this.state.count}</h1>
        <button
          onClick={this.changeMessage}
          style={{ borderRadius: "2px", backgroundColor: "black" }}
        >
          click here
        </button>
      </div>
    );
  }
}
