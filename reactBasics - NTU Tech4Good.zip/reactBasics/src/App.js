import Calculator from "./components/calculator"
import "./components/calculator.css"
import './App.css';
import FunctionComponent from "./contents/functionComponents"
import ClassComponent from "./contents/classComponent"
import ArrowFunction from "./contents/arrowfunComponent"
import ClassProps from "./contents/classProps"
import FunctionalProps from "./contents/functionalProps";
import ArrowFunctionProps from "./contents/arrowFunProps";
import ClassState from "./contents/classState";
import FunctionalState from "./contents/functionalState";
import OnclickFunction from "./contents/onclick"
import OnSumbitForm from "./contents/onsumbit";
import Onchange from "./contents/onchange";
import Useeffect from "./contents/useeffect";
import Apiget from "./contents/apiget";
import GetApi from "./contents/get";
import Post from "./contents/post";

function App() {
  return (
    <div className="">
      {/* <FunctionComponent />
      <ClassComponent />
      <ArrowFunction />
      <ClassProps name={"ClassProps"}/>
      <FunctionalProps name={"functional props"} />
      <ArrowFunctionProps name = {"arrowfun props"} />
      <ClassState  data = {"state"}/>
     <FunctionalState /> */}
     {/* <OnclickFunction /> */}
      {/* <OnSumbitForm /> */}
     {/* <Onchange />  */}
    {/* <Calculator/> */}
    {/* <Useeffect /> */}
    {/* <Apiget /> */}
    {/* <GetApi /> */}
    <Post />
    </div>
  );
}

export default App;
